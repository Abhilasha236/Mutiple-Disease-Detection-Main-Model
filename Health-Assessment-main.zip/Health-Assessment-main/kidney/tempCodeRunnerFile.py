
# print(os.getc